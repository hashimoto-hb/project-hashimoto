const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// 設定（.envファイルから読み込むことを推奨）
const TETORU_URL = process.env.TETORU_URL || 'https://admin.tetoru.jp';
const EMAIL = process.env.TETORU_EMAIL;
const PASSWORD = process.env.TETORU_PASSWORD;
const DOWNLOAD_DIR = path.join(__dirname, 'output_staff_pdfs');

(async () => {
  if (!EMAIL || !PASSWORD) {
    console.error('エラー: 環境変数 TETORU_EMAIL と TETORU_PASSWORD を設定してください。');
    process.exit(1);
  }

  // 出力ディレクトリの作成
  if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR);
  }

  const browser = await chromium.launch({ headless: false }); // 動作を確認するため画面を表示
  const context = await browser.newContext({
    acceptDownloads: true // PDFのダウンロードを許可
  });
  const page = await context.newPage();

  try {
    console.log('tetoruにログイン中...');
    await page.goto(`${TETORU_URL}/login`);
    
    // ログイン処理（セレクターは一般的なものを想定。適宜調整が必要）
    await page.fill('input[type="email"], input[name="email"]', EMAIL);
    await page.fill('input[type="password"], input[name="password"]', PASSWORD);
    await page.click('button:has-text("ログイン")');
    
    // ダッシュボード読み込み待ち
    await page.waitForNavigation();
    console.log('ログイン成功');

    // 1. 教職員名簿をクリック
    console.log('教職員名簿へ移動中...');
    await page.click('text="教職員名簿"');
    await page.waitForLoadState('networkidle');

    // 全ての「詳細」ボタンを取得
    const detailsButtons = page.locator('text="詳細"');
    const staffCount = await detailsButtons.count();
    console.log(`${staffCount} 名の教職員を検出しました。`);

    for (let i = 0; i < staffCount; i++) {
        // 詳細ボタンを順番にクリック。画面遷移するため、毎回locatorを取得し直す
        const btn = page.locator('text="詳細"').nth(i);
        
        // 職員名の取得（保存ファイル名に使用。表の構造に依存）
        // ここではボタンの親要素の行から名前を取得する例
        const row = page.locator('tr').filter({ has: btn });
        const staffName = (await row.innerText()).split('\t')[0].trim() || `staff_${i}`;

        console.log(`[${i + 1}/${staffCount}] ${staffName} さんの操作を開始...`);
        await btn.click();
        await page.waitForLoadState('networkidle');

        // 3. ログイン情報発行ボタンの特定とクリック
        // PDFによると「ログイン情報発行」または「パスワード再発行」の可能性がある
        const issueBtn = page.locator('text="ログイン情報発行", text="パスワード再発行"');
        
        if (await issueBtn.isVisible()) {
            console.log('  ログイン情報を発行中...');
            
            // PDFが表示されるため、ポップアップ（別タブ）またはダウンロードを待機
            const [download] = await Promise.all([
                page.waitForEvent('download'), // ダウンロードイベントを待機
                issueBtn.click(),
            ]);

            // PDFを保存
            const filePath = path.join(DOWNLOAD_DIR, `${staffName}_ログイン情報.pdf`);
            await download.saveAs(filePath);
            console.log(`  保存完了: ${filePath}`);
        } else {
            console.warn(`  警告: ${staffName} さんの詳細画面に発行ボタンが見つかりませんでした。`);
        }

        // 名簿一覧に戻る
        await page.click('text="教職員名簿"');
        await page.waitForLoadState('networkidle');
    }

    console.log('全ての操作が完了しました。');

  } catch (error) {
    console.error('実行中にエラーが発生しました:', error);
  } finally {
    await browser.close();
  }
})();
